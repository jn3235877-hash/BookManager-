import Banner from '../components/Banner.jsx';

function Home() {
  return (
    <>
      <Banner
        titulo="Cadastrar Livros"
        texto="Gerencie sua biblioteca de forma simples e organizada."
      />

      <section className="cadastro">
        <h2>Bem-vindo ao BookManager</h2>
        <p>
          Use o menu para cadastrar livros, visualizar os livros salvos e buscar
          livros externos usando uma API pública.
        </p>
      </section>
    </>
  );
}

export default Home;

import { useEffect, useState } from 'react';
import Banner from '../components/Banner.jsx';
import CardLivro from '../components/CardLivro.jsx';
import { buscarLivrosSalvos, salvarLivros } from '../services/storage.js';

function Livros() {
  const [livros, setLivros] = useState([]);
  const [busca, setBusca] = useState('');
  const [livrosApi, setLivrosApi] = useState([]);
  const [carregando, setCarregando] = useState(false);

  useEffect(() => {
    setLivros(buscarLivrosSalvos());
  }, []);

  function limparLivros() {
    setLivros([]);
    salvarLivros([]);
  }

  async function buscarLivrosExternos(evento) {
    evento.preventDefault();

    if (busca.trim() === '') {
      return;
    }

    setCarregando(true);

    try {
      const resposta = await fetch(
        `https://openlibrary.org/search.json?title=${encodeURIComponent(busca)}`
      );
      const dados = await resposta.json();

      const resultado = dados.docs.slice(0, 4).map((item) => ({
        id: item.key,
        titulo: item.title,
        autor: item.author_name ? item.author_name[0] : 'Autor não informado',
        ano: item.first_publish_year || 'Ano não informado',
        categoria: 'API Externa'
      }));

      setLivrosApi(resultado);
    } catch (erro) {
      alert('Erro ao buscar livros externos.');
    } finally {
      setCarregando(false);
    }
  }

  return (
    <>
      <Banner
        titulo="Livros Cadastrados"
        texto="Visualize livros salvos no LocalStorage e consulte livros externos."
      />

      <section className="livros">
        <div className="topo-secao">
          <h2>Livros Salvos</h2>
          <button className="botao-secundario" type="button" onClick={limparLivros}>
            Limpar Lista
          </button>
        </div>

        <div className="grid-livros">
          {livros.length === 0 ? (
            <p>Nenhum livro cadastrado.</p>
          ) : (
            livros.map((livro) => <CardLivro key={livro.id} livro={livro} />)
          )}
        </div>
      </section>

      <section className="cadastro">
        <h2>Buscar Livro Externo</h2>

        <form onSubmit={buscarLivrosExternos}>
          <div className="grupo-form campo-inteiro">
            <label>Nome do livro</label>
            <input
              type="text"
              placeholder="Exemplo: Dom Casmurro"
              value={busca}
              onChange={(evento) => setBusca(evento.target.value)}
            />
          </div>

          <button type="submit">
            {carregando ? 'Buscando...' : 'Buscar com Fetch API'}
          </button>
        </form>
      </section>

      {livrosApi.length > 0 && (
        <section className="livros">
          <h2>Resultados da API</h2>
          <div className="grid-livros">
            {livrosApi.map((livro) => (
              <CardLivro key={livro.id} livro={livro} />
            ))}
          </div>
        </section>
      )}
    </>
  );
}

export default Livros;

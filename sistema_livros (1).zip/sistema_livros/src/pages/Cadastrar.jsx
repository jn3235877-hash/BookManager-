import { useState } from 'react';
import Banner from '../components/Banner.jsx';
import { buscarLivrosSalvos, adicionarLivro } from '../services/storage.js';

function Cadastrar() {
  const [formulario, setFormulario] = useState({
    titulo: '',
    autor: '',
    ano: '',
    categoria: 'Romance'
  });
  const [erro, setErro] = useState('');
  const [mensagem, setMensagem] = useState('');
  const [totalLivros, setTotalLivros] = useState(buscarLivrosSalvos().length);

  function alterarCampo(evento) {
    const { name, value } = evento.target;

    setFormulario({
      ...formulario,
      [name]: value
    });
  }

  function validarFormulario() {
    if (formulario.titulo.trim() === '') {
      return 'O título é obrigatório.';
    }

    if (formulario.autor.trim() === '') {
      return 'O autor é obrigatório.';
    }

    if (formulario.ano.trim() === '') {
      return 'O ano é obrigatório.';
    }

    const anoAtual = new Date().getFullYear();
    const anoInformado = Number(formulario.ano);

    if (anoInformado < 1000 || anoInformado > anoAtual) {
      return `Informe um ano entre 1000 e ${anoAtual}.`;
    }

    return '';
  }

  function cadastrarLivro(evento) {
    evento.preventDefault();

    const erroEncontrado = validarFormulario();

    if (erroEncontrado) {
      setErro(erroEncontrado);
      setMensagem('');
      return;
    }

    const novoLivro = {
      id: Date.now(),
      titulo: formulario.titulo.trim(),
      autor: formulario.autor.trim(),
      ano: formulario.ano,
      categoria: formulario.categoria
    };

    const livrosAtualizados = adicionarLivro(novoLivro);

    setTotalLivros(livrosAtualizados.length);
    setFormulario({ titulo: '', autor: '', ano: '', categoria: 'Romance' });
    setErro('');
    setMensagem('Livro cadastrado com sucesso.');
  }

  return (
    <>
      <Banner
        titulo="Cadastrar Livro"
        texto="Preencha os dados para salvar quantos livros quiser no navegador."
      />

      <section className="cadastro">
        <h2>Cadastrar Livro</h2>
        <p>Total de livros cadastrados: {totalLivros}</p>

        <form onSubmit={cadastrarLivro}>
          <div className="grupo-form">
            <label>Título</label>
            <input
              type="text"
              name="titulo"
              placeholder="Digite o título"
              value={formulario.titulo}
              onChange={alterarCampo}
            />
          </div>

          <div className="grupo-form">
            <label>Autor</label>
            <input
              type="text"
              name="autor"
              placeholder="Digite o autor"
              value={formulario.autor}
              onChange={alterarCampo}
            />
          </div>

          <div className="grupo-form">
            <label>Ano</label>
            <input
              type="number"
              name="ano"
              placeholder="Digite o ano"
              value={formulario.ano}
              onChange={alterarCampo}
            />
          </div>

          <div className="grupo-form">
            <label>Categoria</label>
            <select
              name="categoria"
              value={formulario.categoria}
              onChange={alterarCampo}
            >
              <option>Romance</option>
              <option>Tecnologia</option>
              <option>Ficção</option>
              <option>História</option>
            </select>
          </div>

          {erro && <p className="erro">{erro}</p>}
          {mensagem && <p className="sucesso">{mensagem}</p>}

          <button type="submit">Cadastrar Livro</button>
        </form>
      </section>
    </>
  );
}

export default Cadastrar;

import Banner from '../components/Banner.jsx';

function Sobre() {
  return (
    <>
      <Banner
        titulo="Sobre o Projeto"
        texto="Aplicação front-end desenvolvida com React para cadastro de livros."
      />

      <section className="cadastro">
        <h2>Recursos utilizados</h2>
        <p>HTML semântico, CSS, Flexbox, Grid Layout, React, componentes, props, useState, useEffect, React Router, LocalStorage, Fetch API e manipulação de JSON.</p>
      </section>
    </>
  );
}

export default Sobre;

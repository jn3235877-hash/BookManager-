function CardLivro({ livro }) {
  return (
    <article className="card">
      <h3>{livro.titulo}</h3>
      <p>{livro.autor}</p>
      <span>{livro.ano}</span>
      <small>{livro.categoria}</small>
    </article>
  );
}

export default CardLivro;

import { Link } from 'react-router-dom';

function Header() {
  return (
    <header>
      <div className="logo">📚 Biblioteca</div>
      <nav>
        <ul>
          <li><Link to="/">Início</Link></li>
          <li><Link to="/livros">Livros</Link></li>
          <li><Link to="/cadastrar">Cadastrar</Link></li>
          <li><Link to="/sobre">Sobre</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;

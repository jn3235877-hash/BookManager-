function Footer() {
  return (
    <footer>
      <p>© 2026 BookManager - Sistema de Cadastro de Livros</p>
    </footer>
  );
}

export default Footer;

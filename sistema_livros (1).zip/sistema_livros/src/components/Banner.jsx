function Banner({ titulo, texto }) {
  return (
    <section className="banner">
      <h1>{titulo}</h1>
      <p>{texto}</p>
    </section>
  );
}

export default Banner;

const CHAVE_LIVROS = 'livros';

export function buscarLivrosSalvos() {
  const dados = localStorage.getItem(CHAVE_LIVROS);
  return dados ? JSON.parse(dados) : [];
}

export function salvarLivros(livros) {
  localStorage.setItem(CHAVE_LIVROS, JSON.stringify(livros));
}

export function adicionarLivro(livro) {
  const livrosSalvos = buscarLivrosSalvos();
  const livrosAtualizados = [...livrosSalvos, livro];
  salvarLivros(livrosAtualizados);
  return livrosAtualizados;
}

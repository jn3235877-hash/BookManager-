# BookManager - Cadastro de Livros

Projeto front-end desenvolvido em React para cadastro e listagem de livros.

## Funcionalidades

- Cadastro de livros com validação de formulário.
- Armazenamento dos livros no LocalStorage.
- Listagem dos livros cadastrados.
- Busca externa de livros usando Fetch API.
- Navegação entre páginas com React Router.
- Componentização com React, props, useState e useEffect.

## Tecnologias

- React
- Vite
- React Router DOM
- HTML5
- CSS3
- JavaScript
- LocalStorage
- Fetch API

## Como executar

```bash
npm install
npm run dev
```

Depois, acesse o endereço exibido no terminal.
